## MVP
- [✅] Navbar
- [✅] Footer
- [✅] Picture
- [✅] Projects
- [] Programming Skills

Next Iteration To Do List:
- [] Contact Form
- [] Remove Email Address
- [] Resume
- [] Project Descriptions

- Background - doesnt look modern
- Picture review or remove
- Move name to navbar and reduce in size
- reduce project size and add descriptions
- Add CSS grid
  - see W.Bos
  - css garden game
- Fix flexbox
  - see W.Bos
  - froggy game
- Add Contact form
